<?php

namespace App\Http\Controllers;

use App\Models\Review;
use Illuminate\Routing\Controller;

class HomePageController extends Controller
{
    public function index()
    {
        $reviews = Review::latest()->take(5)->get();
        return view('home-page', compact('reviews'));
    }
}
