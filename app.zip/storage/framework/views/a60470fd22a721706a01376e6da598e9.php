<?php if($errors->any()): ?>
    <div class="mb-4 p-4 bg-red-100 text-red-700 rounded">
        <ul class="list-disc pl-5">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto mt-10">
    <div class="bg-white p-8 rounded shadow">
        <h2 class="text-2xl font-bold mb-6">Add New Review</h2>

        <form action="<?php echo e(route('reviews.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-4">
            <?php echo csrf_field(); ?>

            <input type="text" name="title" placeholder="Title" required class="w-full px-4 py-2 border rounded" />

            <input type="file" name="image" accept=".jpg,.jpeg" required class="w-full px-4 py-2 border rounded" />

            <select name="category" required class="w-full px-4 py-2 border rounded">
                <option value="">Select Category</option>
                <option value="Book">Book</option>
                <option value="Movie">Movie</option>
                <option value="TV Series">TV Series</option>
            </select>

            <textarea name="excerpt" rows="8" placeholder="Write your review (max 1200 words)" required class="w-full px-4 py-2 border rounded"></textarea>
            <div class="text-xs text-gray-500 mt-1">Maximum 1200 words allowed.</div>

            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Save Review</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\chirps\resources\views/admin/create.blade.php ENDPATH**/ ?>