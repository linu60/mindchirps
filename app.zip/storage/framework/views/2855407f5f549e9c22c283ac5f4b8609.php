<?php
    use Illuminate\Support\Str;
?>

<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto mt-12">
    <div class="space-y-6">
        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
                <div class="bg-[#1e525b] px-6 py-4">
                    <h2 class="text-white text-xl font-semibold"><?php echo e($review->title); ?></h2>
                </div>

                <div class="flex px-6 py-4 gap-6 items-start">
                    <div class="w-32 h-48 flex-shrink-0">
                        <img src="<?php echo e(asset('storage/' . $review->image)); ?>" alt="Book Cover" class="w-full h-full object-cover rounded">
                    </div>
                    <div class="flex-grow">
                        <p class="text-gray-700 text-base leading-relaxed text-justify">
                            <?php echo e(Str::limit($review->excerpt, 400)); ?>

                        </p>
                       <a href="<?php echo e(route('reviews.show', $review->id)); ?>" class="text-black-800 text-bold">
    Continue Reading
</a>
                    </div>
                </div>

                <div class="px-3 py-2 bg-gray-100 flex justify-end items-center border-t border-gray-200">
                    <button class="bg-gray-500 text-white text-sm px-4 py-2 rounded hover:bg-gray-600">
                        <?php echo e($review->category); ?>

                    </button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\chirps\resources\views/home-page.blade.php ENDPATH**/ ?>