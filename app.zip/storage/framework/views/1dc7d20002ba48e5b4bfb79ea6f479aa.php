<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sammy's MindChirps</title>

  <link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body class="bg-cover bg-center bg-fixed text-gray-900" style="background-image: url('<?php echo e(asset('images/bg.jpg')); ?>');">

  <?php echo $__env->make('components.layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <div class="w-full flex justify-end">
    <div class="px-4 py-8 flex flex-col lg:flex-row-reverse lg:gap-6">
      <aside class="w-full lg:w-[280px] space-y-6">
        <?php echo $__env->make('components.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      </aside>

      <div class="w-full lg:w-[800px] space-y-8">
        <?php echo $__env->yieldContent('content'); ?>
      </div>
    </div>
  </div>

  <?php echo $__env->make('components.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\chirps\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>