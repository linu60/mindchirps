<aside class="space-y-6">
  <!-- About Section -->
  <div class="bg-white p-5 rounded-xl shadow mb-2">
    <div class="font-semibold text-lg mb-2">About Sammy’s MindChirps</div>
    <p class="text-gray-700 text-sm">
      Sammy’s MindChirps explores cinema, communication, and creativity through reviews, reflections, and recommendations. Whether you're here to discover your next favorite film or book, welcome!
    </p>
  </div>

  <!-- Newsletter Section -->
  <div class="bg-white p-5 rounded-xl shadow mb-2">
    <div class="font-semibold text-lg mb-2">Subscribe to Newsletter</div>
    <input type="email" placeholder="Enter your email" class="w-full border rounded px-3 py-2 text-sm mb-2" />
    <button class="bg-blue-600 text-white px-4 py-2 rounded text-sm w-full hover:bg-blue-700 transition">Subscribe</button>
  </div>


  <!-- Categories Section -->
  <div class="bg-white p-5 rounded-xl shadow mb-2">
    <div class="font-semibold text-lg mb-2">Categories</div>
    <ul class="text-sm text-gray-700 space-y-1">
      <li><a href="#" class="text-blue-700 hover:underline">Book Reviews</a></li>
      <li><a href="#" class="text-blue-700 hover:underline">Movie Reviews</a></li>
      <li><a href="#" class="text-blue-700 hover:underline">TV Series Reviews</a></li>
    </ul>
  </div>
</aside>
<?php /**PATH C:\xampp\htdocs\chirps\resources\views/components/layouts/sidebar.blade.php ENDPATH**/ ?>