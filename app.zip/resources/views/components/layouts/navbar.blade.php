<nav class="bg-[#1e525b] text-white py-2 px-6 shadow">

  <div class="flex items-center space-x-3">
    <!-- Logo -->
    <img src="{{ asset('images/logo.png') }}" alt="Logo" class="h-16 w-16 object-contain">

    <!-- Brand Name -->
    <span class="text-2xl font-satisfy tracking-wide">Sammy’s MindChirps</span>
  </div>
</nav>
